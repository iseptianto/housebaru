This path contains processed data files. 
